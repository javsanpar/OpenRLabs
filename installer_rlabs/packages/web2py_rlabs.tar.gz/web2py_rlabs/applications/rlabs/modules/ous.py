# -*- coding: utf-8 -*-


##############################################################################
# Modulo encargado de gestionar info sobre ous
##############################################################################
import http_actions
import adoDB_ous

def get_ou_credentials(db, ou_id):    
    return adoDB_ous.get_ou_credentials(db, ou_id)


def update_ous_in_table(db, ous):
    adoDB_ous.update_ous_in_table(db, ous)

       
def delete_ous_not_in_ous_server(db, ous):
    adoDB_ous.delete_ous_not_in_ous_server(db, ous)
            
            
def synchronize_table_OUs(db, ous):
    adoDB_ous.update_ous_in_table(db, ous)        
    adoDB_ous.delete_ous_not_in_ous_server(db, ous)    
    
def get_queryOUs(db):
    return adoDB_ous.get_queryOUs(db)


def getOUS(__OPENGNSYS_SERVER__, __APIKEY__):
    recurso = __OPENGNSYS_SERVER__ + "/ous"
    return http_actions.doGET(__APIKEY__, recurso)    