# -*- coding: utf-8 -*-


##############################################################################
# Modulo encargado de gestionar info sobre repos
##############################################################################
import adoDB_repos
import http_actions
import opengnsys


def get_API_repo(db, repo_name):       
    return adoDB_repos.get_API_repo(db, repo_name)

def get_repos(db):
    return adoDB_repos.get_repos(db)


def get_repoInfo(ou_id, repo_id):
    recurso = opengnsys.__OPENGNSYS_SERVER__ + "/ous/" + str(ou_id) + "/repos/" + str(repo_id)
    
    return http_actions.doGET(opengnsys.__APIKEY__, recurso)

def poweron(repo_info, mac):
    print('poweron')            
    
    recurso = "https://" + str(repo_info['ip']) + "/opengnsys/rest/repository/poweron"
    
    parametros = {
                    "macs": [
                            __formated_mac(mac)
                            ]
                }            

        
    return http_actions.doPOST(recurso, parametros, repo_info['api_repo'])    
        
    



def __formated_mac(mac):
    return ':'.join(mac[i:i+2] for i in range(0,12,2))