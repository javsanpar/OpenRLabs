# -*- coding: utf-8 -*-


##############################################################################
# Modulo encargado de gestionar info sobre repos en BBDD
##############################################################################

def get_API_repo(db, repo_name):       
    return db(db.openRLabs_repos.name == repo_name).select().first()['api_token']

def get_repos(db):
    return (db.openRLabs_repos.id>0)
