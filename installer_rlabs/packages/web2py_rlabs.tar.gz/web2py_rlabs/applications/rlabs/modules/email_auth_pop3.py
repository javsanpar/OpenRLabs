# -*- coding: utf-8 -*-
import gluon
import poplib
import logging


    
def email_auth_pop3(server, domain, tls_mode=None):
    
    def email_auth_pop3_aux(email,
                       password,
                       server=server,
                       domain=domain,
                       tls_mode=tls_mode):
            
        (host, port) = server.split(':')
        (user) = ''.join(email).split('@')[0]
        
        try:            
            pop3 = None
            pop3 = poplib.POP3_SSL(host, port) if tls_mode else poplib.POP3(host, port)                
            pop3.user(user)            
            auth_response = pop3.pass_(password)
            pop3.quit()
            if "+OK" in auth_response.decode('utf-8'):                
                return True
            else:
                logging.exception('email_auth() failed')
                return False
        except:
            logging.exception('email_auth() failed')
            if pop3:
                try:
                    pop3.quit()
                except:  # server might already close connection after error
                    pass
            return False
        
    return email_auth_pop3_aux
    
