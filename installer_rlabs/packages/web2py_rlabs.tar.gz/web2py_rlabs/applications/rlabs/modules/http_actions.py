# -*- coding: utf-8 -*-


##############################################################################
# Modulo encargado de implementar las acciones http sobre el API 
##############################################################################

import urllib3
import json


urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)



# Using such a timeout and retries setup to secure that: check PC is ON, with __doGET() method, 
# is trying it during 5 minutes aprox.
     
http = urllib3.PoolManager(num_pools=10, maxsize=10, cert_reqs='CERT_NONE',
                            assert_hostname=False)




def doGET(__APIKEY__, recurso, timeout=60.0, retries = 3, redirect = 3):     
    try:  
        respuesta_json = http.request(
                                'GET',
                                recurso,
                                headers={'Accept': 'application/json',
                                         'Authorization': __APIKEY__},
                                timeout=timeout, retries=retries, redirect=redirect)                
        
        return json.loads(respuesta_json.data.decode('utf-8'))
    except urllib3.exceptions.MaxRetryError:        
        return {'error': 'Error de conexión.'}
    
    
def doDELETE(__APIKEY__, recurso, timeout=60.0, retries = 3, redirect = 3):    
    respuesta_json = http.request(
                            'DELETE',
                            recurso,
                            headers={'Accept': 'application/json',
                                     'User-Agent': 'python-requests//',
                                     'Authorization': __APIKEY__},
                            timeout=timeout, retries=retries, redirect=redirect)        

    return json.loads(respuesta_json.data.decode('utf-8'))
    
             
def doPOST(recurso, parametros, apikey, timeout=60.0, retries = 3, redirect = 3):
    parametros_json = json.dumps(parametros).encode('utf-8')
    
    respuesta_json = http.request(
                        'POST',
                        recurso,
                        body = parametros_json,
                        headers={'Content-Type': 'application/json',
                                 'Accept': 'application/json',
                                 'Authorization': apikey,
                                 'User-Agent': 'python-requests//'},
                        timeout=timeout, retries=retries, redirect=redirect)        
    
    return json.loads(respuesta_json.data.decode('utf-8'))    