# -*- coding: utf-8 -*-


##############################################################################
# Modulo encargado de acceder info de los usuarios en DDBB
##############################################################################

def get_users(db):
    return (db.auth_user.id>0)

def get_users_menbership(db):
    return (db.auth_membership.id>0)
