# -*- coding: utf-8 -*-


##############################################################################
# Modulo encargado de gestionar info sobre servidores
##############################################################################
import adoDB_servers

def get_openGnsys_server(db):
    return adoDB_servers.get_openGnsys_server(db)

def get_openRLabs_server(db):
    return adoDB_servers.get_openRLabs_server(db)

def get_Apache_Guacamole_WebSocket(db):
    return adoDB_servers.get_Apache_Guacamole_WebSocket(db)


def getSetup_OpenRLabs_table(db):
    return db.openRLabs_setup

def getSetup_OpenRLabs(db):    
    return db(db.openRLabs_setup.id > 0).select().first()
