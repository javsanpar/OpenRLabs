# -*- coding: utf-8 -*-


##############################################################################
# Modulo encargado de gestionar info sobre ous en BBDD
##############################################################################

def get_ou_credentials(db, ou_id):    
    return (db(db.ous_setup.ou_id == ou_id).select().first())


def update_ous_in_table(db, ous):
    for ou in ous:
        db.ous_setup.update_or_insert(db.ous_setup.ou_id == ou['id'],
                                      ou_id = ou['id'],
                                      ou_name = ou['name'])
       
def delete_ous_not_in_ous_server(db, ous):
    ous_table = db(db.ous_setup.id > 0).select()
    for ou_table in ous_table:
        exist = False
        for ou in ous:  
                      
            if  ou['id'] == int(ou_table.ou_id) :
                exist = True
                        
        if exist == False:
            ou_table.delete_record()
            
                
def get_queryOUs(db):
    return (db.ous_setup.id>0)
        