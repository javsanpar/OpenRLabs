# -*- coding: utf-8 -*-


##############################################################################
# Modulo encargado de gestionar info sobre clients
##############################################################################
import http_actions
import opengnsys

import time

def __get_url_base(ou_id, lab_id):
    return  opengnsys.__OPENGNSYS_SERVER__ + "/ous/" + ou_id + "/labs/" + lab_id + "/clients"

def __get_url_base_pc(ou_id, lab_id, pc_id):
    return __get_url_base(ou_id, lab_id) + '/' + pc_id

def __getClients(ou_id, lab_id):
    recurso = __get_url_base(ou_id, lab_id)
    
    clients = http_actions.doGET(opengnsys.__APIKEY__, recurso)
    
    return sorted(clients, key = lambda k:k['name'], reverse=True)

def __getStatusClients(ou_id, lab_id):
    recurso = __get_url_base(ou_id, lab_id) + "/status"
    return  http_actions.doGET(opengnsys.__APIKEY__, recurso)

def __getStatusClientFromClient(pc_ip):
    recurso = "https://" + pc_ip + ":8000/opengnsys/status" 
    return  http_actions.doGET(opengnsys.__APIKEY__, recurso, 0.05, 1, 1)

def __getStatusClient(ou_id, lab_id, pc_id):    
    recurso = __get_url_base_pc(ou_id, lab_id, pc_id) + "/status" # Preguntamos a servidor sobre PC    
    
    return http_actions.doGET(opengnsys.__APIKEY__, recurso)


def __getInfoClient(ou_id, lab_id, pc_id):
    recurso = __get_url_base_pc(ou_id, lab_id, pc_id)
    
    return http_actions.doGET(opengnsys.__APIKEY__, recurso)

def __getDiskConfigClient(ou_id, lab_id, pc_id):
    recurso = __get_url_base_pc(ou_id, lab_id, pc_id) + "/diskcfg"                    
    return http_actions.doGET(opengnsys.__APIKEY__, recurso)                    


def getRemoteClients(ou_id, lab_id):
    
    PCs =  __getClients(ou_id, lab_id)
           
    PCs_info = []
     
    for pc in PCs:
        
        pc_status = __getStatusClientFromClient(pc['ip'])
        
        info_client = __getInfoClient(ou_id, lab_id, str(pc['id']))
        pc['netmask'] = info_client['netmask']
        pc['repo'] = info_client['repo']
        
        pc_info = {}
        
        pc_info['pc'] = pc        
        pc_info['status'] = pc_status        
        pc_diskcfg = __getDiskConfigClient(ou_id, lab_id, str(pc['id'])) 
        info_particiones = []
        for diskcfg in pc_diskcfg['diskcfg']:
            
            if ("parttype"in diskcfg) and (diskcfg['parttype'] == "WINDOWS" or  diskcfg['parttype'] == "LINUX"):
                if 'image' in diskcfg:
                    info_particiones.append({'disk': diskcfg['disk'],
                                             'partition': diskcfg['partition'],
                                             'os' : diskcfg['os'],
                                             'image_id' : diskcfg['image']['id']})
        
                            
        pc_info['info_particiones'] = info_particiones
                          
            
        PCs_info.append(pc_info)
            
    return sorted(PCs_info, key = lambda k:k['pc']['name'], reverse=False)


def check_pc_status(ou_id, lab_id, pc_id, numRetries = 0):
    print("Chequeando")
         
    pc_status = None
                    
    pc_status = __getStatusClient(ou_id, lab_id, pc_id)
       
    # secure not error checking while loop
    if 'status' not in pc_status: 
        pc_status['status'] = 'error'
        
    while (pc_status['status'] == 'off' or pc_status['status'] == 'oglive'
           or pc_status['status'] == 'error') and (numRetries < 2):

        numRetries = numRetries + 1
        
        time.sleep(20)
                
        pc_status = __getStatusClient(ou_id, lab_id, pc_id)
        
        if 'status'not in pc_status: 
            pc_status['status'] = 'error'
                
         
    return pc_status


def check_distinto_SO(status, part_sys):
    
    # Usamos diccionario a modo de swicth-case para poder 
    # mapear la info de particion a los datos del status
    
    sistemas = {
        'Windows' : 'windows',
        'MacOS' : 'osx'        
        }
    
    
    sistema = sistemas.get(part_sys.split(' ')[0], 'linux')
    
    
    if status != sistema:
        return True
    else:
        return False 






def redirect_events(ou_id, lab_id, pc_id, maxtime):
    recurso = __get_url_base_pc(ou_id, lab_id, pc_id) + "/events"
    urlogin = opengnsys.__RLABS_SERVER__ + "/events/getEventsLogin?pc_id=" + pc_id + \
                                                                        "&lab_id=" + lab_id + \
                                                                        "&ou_id=" + ou_id + \
                                                                        "&maxtime=" + maxtime

    urlogout = opengnsys.__RLABS_SERVER__ + "/events/getEventsLogout?pc_id=" + pc_id + \
                                                                        "&lab_id=" + lab_id + \
                                                                        "&ou_id=" + ou_id + \
                                                                        "&maxtime=" + maxtime                                                                        
    parametros = {
              "urlLogin": urlogin,
              "urlLogout": urlogout
            }     
            
    
    return http_actions.doPOST(recurso, parametros, opengnsys.__APIKEY__)        




def register_session_parameters(ou_id, lab_id, pc_id, maxtime):
    recurso = __get_url_base_pc(ou_id, lab_id, pc_id) + "/session"

    deadLine = str(int(maxtime) * 60 * 60)    
    
    parametros ={
         "deadLine": deadLine 
    }

    return http_actions.doPOST(recurso, parametros, opengnsys.__APIKEY__)

def reserveRemotePC(ou_id, lab_id, image_id, pc_id, maxtime):
    print("Haremos reserva")
    
    recurso = opengnsys.__OPENGNSYS_SERVER__ + "/ous/" + ou_id + "/images/" + image_id + \
                                     "/labs/" + lab_id + "/clients/" + pc_id + "/reserve"

    parametros = {
              "maxtime": maxtime     
            }     

    return http_actions.doPOST(recurso, parametros, opengnsys.__APIKEY__)

def unreserveRemotePC(ou_id, lab_id, pc_id):
    print("Cancelamos reserva")    
    recurso = __get_url_base_pc(ou_id, lab_id, pc_id) + "/unreserve"
         
    return http_actions.doDELETE(opengnsys.__APIKEY__, recurso)





