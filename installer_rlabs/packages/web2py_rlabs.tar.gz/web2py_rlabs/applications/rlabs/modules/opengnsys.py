# -*- coding: utf-8 -*-


##############################################################################
# Modulo encargado de intercacciona con la API de opengnsys
##############################################################################


# -------------------------------------------------------------------------
# Obtain credential for access API opengnsys 
# -------------------------------------------------------------------------

import http_actions

import servers
import ous





__OPENGNSYS_SERVER__ = ""
__RLABS_SERVER__ = ""

__APIKEY__ = ""


def setServers(db):                
    global __OPENGNSYS_SERVER__
    __OPENGNSYS_SERVER__ = servers.get_openGnsys_server(db)
    
    global __RLABS_SERVER__
    __RLABS_SERVER__ = servers.get_openRLabs_server(db)

    
def setApiKey(apikey):
    global __APIKEY__
    __APIKEY__ = apikey


# ---- Do Login and return dictionary with UserID  and ApiKey ---        
def doLogin(db, ou_id):
    recurso = __OPENGNSYS_SERVER__ + "/login"
    
    # Usar usuario propietario de la OU (Unidad Organizativa)
    
    ou_credentials = ous.get_ou_credentials(db, ou_id)
    
    parametros = {
              "username": ou_credentials['ou_user'],
              "password": ou_credentials['ou_password']
            }
     
    return http_actions.doPOST(recurso, parametros, __APIKEY__)
    
            
# ---- Return a list of dictionaries {OU_ID: OU_NAME} ---
def getOUS():
    return ous.getOUS(__OPENGNSYS_SERVER__, __APIKEY__)


    
