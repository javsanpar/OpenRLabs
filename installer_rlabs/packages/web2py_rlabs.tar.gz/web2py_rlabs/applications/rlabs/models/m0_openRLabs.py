# -*- coding: utf-8 -*-


db.define_table('openRLabs_setup',
                Field('URL_Apache_Guacamole_WebSocket', required=True),
                Field('URL_openGnsys_server', required=True),
                Field('URL_openRLabs_server', required=True),
                Field('URL_authentication_mail_pop3_server', required=True)
                )
    
if db(db.openRLabs_setup).isempty():
    import load_init_setup
    
    load_init_setup.load_setup(db)
    
#Ensure only one record
idFirst = db(db.openRLabs_setup.id > 1).select().first()['id']
db(db.openRLabs_setup.id != idFirst).delete()

db.openRLabs_setup.id.readable = False