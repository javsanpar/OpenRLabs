

xhr = new XMLHttpRequest();

function requestAJAX(url, parametros, callbackFunction){

    xhr.open("POST", url, true);
    xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');    
    document.getElementById("table_ous").setAttribute("style", "cursor:progress;");
    document.body.setAttribute("style", "cursor:progress;");
    xhr.send(parametros);        

    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4 && xhr.status == 200) {        	
        	var respuesta = JSON.parse(xhr.responseText);        	
        	document.getElementById("table_ous").setAttribute("style", "cursor:pointer;");
        	document.body.style.cursor = "pointer";
        	if (respuesta.error === undefined) { 
	        	
	        	// Use callback for synchronize ajax response with html view        	
	            callbackFunction(respuesta);
	            
	        } else {
	        	alert(respuesta.error);
	        	document.getElementById("buttonConsole").style.display = 'block';
	        	reset_progress_bar();
	        }
        } 
    }    	
}

function hide_progress_bar(animator){
	var progress_bar_container = document.getElementById("progress_bar_container");
	progress_bar_container.style.display = 'none';
	clearInterval(animator);
	document.getElementById("progress_bar").setAttribute("value","0");
	document.getElementById("progress_value").innerHTML="0%";
}

function show__progress_bar(){
	var progress_bar = document.getElementById("progress_bar_container");
	progress_bar.style.display = 'block';
	
	var progressbar = $('#progress_bar'),
	    max = progressbar.attr('max'),
	    time = 2100,
	      value = progressbar.val();
	
	 
	var loading = function() {
	      value += 1;
	      addValue = progressbar.val(value);
	       
	      $('.progress_value').html(value + '%');
	 
	      if (value == max) {
	          clearInterval(animate);                
	      }
	};
	 
	var animate = setInterval(function() {
	      loading();
	}, time);
	
	return animate;
}

function stop_progress_bar(){
	clearInterval(animator);
	document.getElementById("progress_bar").setAttribute("value","100");
	document.getElementById("progress_value").innerHTML="100%";	
}

function reset_progress_bar(){
	clearInterval(animator);
	document.getElementById("progress_bar").setAttribute("value","0");
	document.getElementById("progress_value").innerHTML="0%";	
}

function show_Labs(labs){
	delete_labs();
	labs.forEach(show_Lab);
}

function show_Lab(lab, index){
	// Buscar span id y añadir elemento 	
	var table = document.getElementById("table_ou_" + lab.ou.id);	
	var new_row = table.insertRow();
	new_row.setAttribute("id", "lab_" + lab.id);
	new_row.setAttribute("class", "lab");
	new_row.setAttribute("style", "display:block;");
	new_row.innerHTML =	"<td width='16'>" +
							"<img src='../static/images/aula.png' "  + 
									"data-ou='" + lab.ou.id + "' " +
									"data-lab_id='" + lab.id + "' onClick='get_remotePCs(event)'>" +
						"</td>" +
						"<td>" +
							"<table id='table_lab_" + lab.id + "'>" +
								"<tbody>" +
									"<tr>" +
										"<td>" +									
											"<span " +
												"data-ou='" + lab.ou.id + "' " +
												"data-lab_id='" + lab.id + "' onClick='get_remotePCs(event)'>" +
												lab.name + "</span>" +
										"</td>"+
									"</tr>" +
								"</tbody>" +
							"</table>"
						"</td>"							
}


function getImg_pc(pc_id, status){
	var img;
	if ((typeof(status.status) === "undefined")) {
		img = 'odernador_OFF.png'
	} else {							
		switch (status.status) {
			case 'off':
				img ="odernador_OFF.png"
				break;							
		
			case 'WIN':
				if (('loggedin' in status) && (status.loggedin == true)) {
					img = 'odernador_WINS.png'
				} else {
					img = 'odernador_WIN.png'
				}
				break;
			case 'LNX':
				if (('loggedin' in status) && (status.loggedin == true)) {
					img = 'odernador_LINS.png'
				} else {
					img = 'odernador_LIN.png'
				}
				break;
			case 'OSX':
				img = "odernador_OSX.png"
				break;
			case 'oglive':
				img = "odernador_OPG.png"
				break;
			case 'busy':
				img ="odernador_BSY.png"
				break;							
		
		}
	}
		
	return img;
}

function show_PCs(PCs){
	delete_pcs();
	PCs.forEach(show_PC);	
}

function getImg_sys(sys){	
	var os = sys.split(" ")[0];	
	var img;
	
	switch (os) {
		case 'Windows':
				img = 'windows.png'
			break;
		case 'OSX':
			img = 'osx.png'
		break;
			
		default:
			img = 'tux.png'		
			break;
	}
	
	return img;
}

function show_PC(PC, index){	
	var img = getImg_pc(PC.pc.id, PC.status);

	// Buscar span id y añadir elemento 
	var table = document.getElementById("table_lab_" + PC.pc.lab.id );
	//var row = document.getElementById("lab_" + PC.pc.lab.id);		
	//var new_row = table.insertRow(row.rowIndex + 1);
	var new_row = table.insertRow();	
	new_row.setAttribute("id", "pc_" + PC.pc.id);
	new_row.setAttribute("style", "display:block;");
	new_row.setAttribute("class", "pc");
	var new_cell = new_row.insertCell();
	new_cell.innerHTML ="<img class='status_equipo' src='../static/images/" + img + "' " +
							"data-id='" + PC.pc.id + 
							"' onClick='show_table_partitions(event)'>" 
	new_cell = new_row.insertCell();
	html_begind = "<table id='table_PCs' class='nivel2 table_PCs'>" +
							"<tr id='PC_" + PC.pc.id + "'>" +
								"<td>" +
									"<span data-id='" + PC.pc.id + 
										"' onClick='show_table_partitions(event)'> " +
									PC.pc.name + "</span>" +
								"</td>"	+
							"</tr>" +
							"<tr>" +
								"<table id='table_partitions_" + PC.pc.id + "' class='nivel3 partitions_table'>"
	var i;
	
	
	html_partitions ="";	
	
	for (i=0; i < PC.info_particiones.length; i++) {
		html_partitions += "<tr>" +
								"<td onClick='connect_remotePC(event)'" +
									"data-ip='" + PC.pc.ip + "' " +
									"data-netmask='" + PC.pc.netmask + "' " +
									"data-pc_name='" + PC.pc.name + "' " +
									"data-mac='" + PC.pc.mac + "' " +
									"data-pc_id='" + PC.pc.id + "' " +
									"data-ou='" + PC.pc.ou.id + "' " +
									"data-lab_id='" + PC.pc.lab.id + "' " +
									"data-repo_id='" + PC.pc.repo.id + "' " +
									"data-part_sys='" + PC.info_particiones[i].os  + "' " +
									"data-image_id='" + PC.info_particiones[i].image_id  + "'>" +									
										"<img class='img_sys' src='../static/images/" + getImg_sys(PC.info_particiones[i].os) + 
										"' height='16'>" +
										"<span> Disk: " + PC.info_particiones[i].disk + "</span>" +
										"<span> Partition: " + PC.info_particiones[i].partition + "</span>" +
										"<span> System: " + PC.info_particiones[i].os + "</span>" +
								"</td>" +
							"</tr>"		
							
	}	
	
	html_end =			"</table>" + // End table nivel3
							"</tr>" +
				"</table>" // End table nivel2
	
	
	html = html_begind + html_partitions + html_end;
	
	
	
	new_cell.innerHTML = html_begind.concat(html_partitions, html_end);
	
}

function delete_by_class(class_name){
	var class_items = document.getElementsByClassName(class_name);
	for (i = class_items.length - 1; i > -1 ; i --){
		class_items[i].remove();
	}		
}

function hide_by_class(class_name){
	var class_items = document.getElementsByClassName(class_name);	
	for (i = 0; i < class_items.length -1; i ++){
		class_items[i].style.display = 'none';
	}		
}
function show_table_partitions(event){
	hide_by_class('partitions_table');

	
	var pc_id = event.target.getAttribute('data-id');
	var id = event.target.getAttribute('id');
	
	document.getElementById("table_partitions_" + pc_id).style.display = 'block';
	
}



function delete_labs(){	
	delete_by_class('lab');
}


function delete_pcs(){
	delete_by_class('pc');	
}

function redirect_remotePC(connect_data){
	//console.log(connect_data);
	if (typeof(connect_data.error) === "undefined"){
		document.getElementById("ip_remotePC").value=connect_data.ip;		
		document.getElementById("pc_id_remotePC").value=connect_data.pc_id;
		document.getElementById("pc_name_remotePC").value=connect_data.pc_name;
		document.getElementById("lab_id_remotePC").value=connect_data.lab_id;
		document.getElementById("ou_id_remotePC").value=connect_data.ou_id;		
		document.getElementById("maxtime_remotePC").value=connect_data.maxtime;
		document.form.submit();        			
	} else {
		alert(connect_data.error);
	}
	
}

function reset_modal(){	
	document.getElementById("text_consolelog").value = '';    
	document.getElementById("buttonConsole").style.display = 'none';
	reset_progress_bar();
	delete_pcs();
}
