# -*- coding: utf-8 -*-


##############################################################################
# Controller for properties setup
##############################################################################

import servers
import ous
import repos
import adoDB_users

@auth.requires_membership('admin')
def index():
    return dict()

@auth.requires_membership('admin')
def openRLabs():            
    setups = servers.getSetup_OpenRLabs(db)
    
    if setups:     
        form = SQLFORM(servers.getSetup_OpenRLabs_table(db), setups)
    else:
        form =  SQLFORM(servers.getSetup_OpenRLabs_table(db))
            
    if form.process().accepted:
       response.flash = 'form accepted'
    elif form.errors:
       response.flash = 'form has errors'
                   
    return dict(form=form)

def OUs():
    import opengnsys
    
    ous.synchronize_table_OUs(db, opengnsys.getOUS())

    grid = SQLFORM.grid(ous.get_queryOUs(db), csv=False,
                        details=False, deletable=False, paginate = 10)
    
    return dict(grid=grid)

def repositories():
    grid = SQLFORM.grid(repos.get_repos(db), csv=False,
                        details=False, paginate = 10)
    
    return dict(grid=grid)    
    
def manage_users():
    grid = SQLFORM.grid(adoDB_users.get_users(db), csv=False,
                        details=False, paginate = 10)
    return dict(grid=grid)
    
def enable_users():
    grid = SQLFORM.grid(adoDB_users.get_users_menbership(db), csv=False,
                        details=False, deletable=False, paginate = 10)
    
    return dict(grid=grid)    