# -*- coding: utf-8 -*-
# -------------------------------------------------------------------------
# Controller for connect to remote pc actions
# -------------------------------------------------------------------------


import gluon # quitar en produccion. Sirve para que eclipse no de errores.

import connection_stage
import servers
import clients

import json

@auth.requires_membership('enabled')   
def connect_remotePC_init_stage():
    
    connection_stage.init_parameters(request)
    
    return json.dumps(connection_stage.exec_stage())

def connect_remotePC_next_stage():
    import connection_stage
    import json
    
    connection_stage.increment_stage()
    
    return json.dumps(connection_stage.exec_stage())
            
def show_remotePC():
    
    
    #print("conectando")
    #print(request.vars.ip)
    
    #print('redirigiendo eventos')
    if request.vars.ou_id and request.vars.lab_id and request.vars.pc_id and request.vars.maxtime:
        resultado = clients.redirect_events(request.vars.ou_id, 
                                              request.vars.lab_id,
                                              request.vars.pc_id,
                                              request.vars.maxtime)    
        #print('eventos redirigidos')
        #print(resultado)                
        
    return dict(ip=request.vars.ip, pc_name=request.vars.pc_name, ou_id = request.vars.ou_id,
                lab_id = request.vars.lab_id, pc_id = request.vars.pc_id,
                url_webSocket = servers.get_Apache_Guacamole_WebSocket(db))


